

access_token = 'vk1.a.rMuG3FyoG2ls5bbgsmBe9NgfRMAXfR4sk5Pp36wBSdmiEd1bFp2u7y7w9pm-TpkvfD-YIeJ-JZSzm1n4-OEdhmQu2S85GoLSyuWNNQoNTAOUL5Zgr2rsjwplXzRcwUj-ze7SPDimxjTN1s430ZGNt43uMPjsA2o6DKh-izlzd2NI-atYTQyvmCy5r3djmRGlGR43NpHHLWY5lqSmAZNgNQ'
community_token = 'vk1.a.PI0ZRBLXDlvWBDjfAN3Ei5WlO39UIGqlygjg1kusdSt9KMoLTNJdWOpsYIW-82Vn6agWEB2ktgasRCKI0EshVyPMMqN12AzT7U6vilTuzOLfSP5sWGqvDkcnkD2Y1iOY8SvV3ElHvvDd8ASE9Kr-X2yevdLuzrUPsIeHcegdfSOTNYubpBE-LbbkDZbtp_q4X7YafQQ3mxvV-01weIKtuQ'

db_config = {
    'db_name': 'datingdb',
    'host': 'localhost',
    'user': 'postgres',
    'password':''
}

